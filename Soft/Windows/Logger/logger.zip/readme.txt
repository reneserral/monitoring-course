Adiscon Logger 1.3

A UNIX-like logger tool for Windows.

This is Release Candidate 1.0 of Adiscon's logger. This program is
free to use. In free mode, a nag screen appears each time when you
start file logging and every 1000 lines. Other than that, there are no
restrictions. IF you would like to remove the nag screen, please 
register the product at

http://www.monitorware.com/logger/

This program is Copyrighted (C) 2003-2006 by Adiscon GbmH (www.adiscon.com). 
Adiscon makes no warrenty of any kind. Please evaluate the program before
putting it into your production. Adiscon accepts no liability for this
product. Please use at your sole risk.

See logger.pdf for details.